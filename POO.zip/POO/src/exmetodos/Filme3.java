package exmetodos;

public class Filme3 {
	public static int pontuarFilme(int s, int a, int d){
			return s + a + d; }
}