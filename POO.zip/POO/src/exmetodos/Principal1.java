package exmetodos;

public class Principal1 {
	public static void main (String argv[]){
		int script = 6, atuacao = 9, direcao = 8;
		System.out.print("A pontuação do filme é ");
	System.out.println(Filme3.pontuarFilme(script,atuacao,direcao))
	;
	}
}